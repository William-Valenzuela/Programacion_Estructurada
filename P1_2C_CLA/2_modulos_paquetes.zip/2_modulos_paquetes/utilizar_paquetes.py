from paquete1 import modulos

print(modulos.saludar("Daniel Contreras Ruano"))

